#!/usr/bin/env node

/**
 * Test Session End Consolidation functionality
 */

const sessionEndModule = require('./core/session-end');
const onSessionEnd = sessionEndModule.handler || sessionEndModule.onSessionEnd || sessionEndModule;

// Create test conversation that matches the OAuth example
const mockConversation = {
    messages: [
        {
            role: 'user',
            content: 'I need to implement OAuth authentication for my web app. What approach should we use?'
        },
        {
            role: 'assistant',
            content: 'For OAuth authentication, I recommend using Auth0 with JWT tokens. This will give you enterprise-grade security with minimal setup complexity.'
        },
        {
            role: 'user',
            content: 'That sounds good. We decided to use Auth0 with JWT tokens for authentication. What are the next steps?'
        },
        {
            role: 'assistant',
            content: 'Great decision! Next steps are: 1) Configure environment variables for Auth0, 2) Set up the Auth0 application dashboard, 3) Test the authentication flow with a simple login page. I learned that Auth0 provides excellent documentation for JWT integration.'
        }
    ]
};

// Create mock context similar to what Claude Code would provide
const mockContext = {
    workingDirectory: '/Users/example/my-web-app',
    sessionId: 'test-session-oauth-2024',
    sessionDuration: 45 * 60 * 1000, // 45 minutes in milliseconds
    conversation: mockConversation
};

console.log('🧪 Testing Session End Consolidation');
console.log('═'.repeat(60));
console.log('Testing with OAuth authentication conversation...\n');

// Test the session end hook
onSessionEnd(mockContext)
    .then(() => {
        console.log('\n✅ Session consolidation test completed successfully!');
        console.log('📝 The hook should have:');
        console.log('  ✓ Analyzed the conversation for topics, decisions, insights');
        console.log('  ✓ Generated smart tags based on content and project');
        console.log('  ✓ Formatted a rich session summary');
        console.log('  ✓ Attempted to store the memory automatically');
        console.log('  ⚠️  Storage may fail due to no active memory service (expected)');
    })
    .catch(error => {
        console.error('\n❌ Session consolidation test failed:', error.message);
    });